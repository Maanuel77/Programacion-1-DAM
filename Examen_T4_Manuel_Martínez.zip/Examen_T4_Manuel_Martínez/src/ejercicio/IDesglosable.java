package ejercicio;

public interface IDesglosable {

    double calcular_Sueldo_Neto(double sueldo_Bruto, double porcentaje_Impuesto);
}